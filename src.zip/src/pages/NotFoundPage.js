import React from 'react';

export const NotFoundPage = () => (
    <h1>404 Page Not Found</h1>
);