export { ControlledFormPage } from './ControlledFormPage';
export { UncontrolledFormPage } from './UncontrolledFormPage';
export { CounterButtonPage } from './CounterButtonPage';
export { PeopleListPage } from './PeopleListPage';
export { HomePage } from './HomePage';
export { NotFoundPage } from './NotFoundPage';
export { ProtectedPage } from './ProtectedPage';
export { UserProfilePage } from './UserProfilePage';