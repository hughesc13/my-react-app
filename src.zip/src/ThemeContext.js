import React from 'react';

export const ThemeContext = React.createContext();
//starting value for theme context is light